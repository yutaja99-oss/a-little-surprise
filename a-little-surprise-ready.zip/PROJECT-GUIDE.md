# A Little Surprise For You — Ready Project

## Langsung dijalankan
### Tanpa install
Buka `index.html` di browser.

### Dengan local server
```bash
python3 -m http.server 8080
```
Kemudian buka `http://localhost:8080`.

## Edit dari website
Klik tombol **✎** di kanan atas. Kamu dapat mengubah:
- nama pasangan
- nama kamu
- tanggal spesial
- kode brankas
- surat
- pesan final
- URL share

Perubahan disimpan di browser.

## Foto
Ganti file di `images/`:
- photo1.jpg sampai photo4.jpg
- memory1.jpg sampai memory6.jpg

File SVG yang tersedia adalah fallback agar project tetap bisa langsung dicoba.

## Musik
Taruh musik di:
`audio/romantic.mp3`

## Publish
Upload seluruh folder ini ke hosting static seperti GitHub Pages, Netlify, Vercel, atau hosting kamu sendiri.

Setelah mendapatkan URL publik:
1. buka website
2. tekan ✎
3. masukkan URL publik
4. simpan
5. gunakan QR yang dibuat

QR menggunakan error correction tinggi. Frame hati bersifat dekoratif dan tidak menutup modul QR sehingga kamera HP tetap dapat membacanya.

## Struktur
- `index.html` — aplikasi utama
- `images/` — foto
- `audio/` — musik
- `src/data/surprise.js` — contoh struktur data
- `README.md` — panduan
- `package.json` — metadata/script project
