# A Little Surprise For You

Website romantis interaktif, mobile-first, tanpa framework/build step.

## Cara edit
1. Buka `index.html`.
2. Tekan `Ctrl+E` (desktop) untuk membuka editor, atau tambahkan tombol pemanggil `openEditor()` jika ingin tombol editor terlihat.
3. Isi nama pasangan, nama kamu, tanggal, kode brankas, surat, pesan akhir, dan URL publik.
4. Foto taruh di folder `images/` dengan nama:
   - photo1.jpg ... photo4.jpg
   - memory1.jpg ... memory6.jpg
5. Musik opsional: `audio/romantic.mp3`.

## Cara membagikan
Upload folder ini ke layanan hosting statis seperti GitHub Pages, Netlify, Vercel, atau hosting web biasa. Setelah mendapat URL publik, buka editor, masukkan URL tersebut pada bagian QR, lalu QR akan otomatis dibuat.

PENTING: QR yang benar-benar bisa dipindai harus menunjuk ke URL publik. URL file lokal seperti file:///... tidak bisa dipakai pasangan dari HP lain.

## QR berbentuk love
QR dibuat dengan error correction tinggi dan dibungkus frame hati. Area kode tidak ditutupi dekorasi agar kamera HP tetap mudah membacanya.

## Catatan
Foto fallback memakai placeholder online bila file lokal belum tersedia. Untuk pengalaman final, ganti dengan foto sendiri.
