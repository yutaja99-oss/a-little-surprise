// Data utama juga dicontohkan di dalam index.html agar website bisa langsung jalan.
// Gunakan editor bawaan (Ctrl+E) untuk mengubah data tanpa menyentuh komponen.
export const surpriseData = {
  partnerName: "Nama Pasangan",
  senderName: "Nama Kamu",
  specialDate: "30 September 2026",
  safeCode: "143",
  photos: [
    {src:"/images/photo1.jpg", caption:"Our first memory ❤️"},
    {src:"/images/photo2.jpg", caption:"One of my favorite days."},
    {src:"/images/photo3.jpg", caption:"Look at us..."},
    {src:"/images/photo4.jpg", caption:"Another little piece of us."}
  ],
  memories: [
    "/images/memory1.jpg","/images/memory2.jpg","/images/memory3.jpg",
    "/images/memory4.jpg","/images/memory5.jpg","/images/memory6.jpg"
  ]
};
